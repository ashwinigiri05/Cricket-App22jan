export class Player{
    
    private name:string;
    private Balling:string;
    private Batting: string;
    
    constructor(name:string,Balling:string,Batting:string){
        this.name=name;
        this.Balling=Balling;
        this.Batting=Batting;
    }
    
    setPlayersName(name:string){
        this.name=name;
    }
     
    getName(){
        return this.name;
    }
}