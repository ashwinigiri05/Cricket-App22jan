import { Player } from './Players';

export class Team{

    players:Array<Player> = [];
    constructor(){

     for (let index = 0; index < 11; index++) {
        const Players = this.players[index];
        //this.player.push(this.players)
        this.players.push(Players);
    }
       
    }
    isTeamCompleted():Boolean{
        if(this.players.length === 11){
        return true;
    }
    return false;
    }
    
   getPlayerName(){
       return this.players;
   }
}