export class Bowling{
    private didNotBowl:boolean;
    
    constructor() {
        this.didNotBowl=true;
    }
}