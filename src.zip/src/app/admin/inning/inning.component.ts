import { Component, OnInit } from '@angular/core';
import { MatchService } from 'src/app/services/match.service';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-inning',
  templateUrl: './inning.component.html',
  styleUrls: ['./inning.component.css']
})
export class InningComponent implements OnInit {

  constructor( 
    public matchService: MatchService,
    private router:Router,
    private route:ActivatedRoute
    ) { }
  

  ngOnInit() {
  }

}
